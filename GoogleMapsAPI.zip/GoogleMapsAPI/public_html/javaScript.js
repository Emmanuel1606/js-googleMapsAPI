
var LatitudeInputted = window.prompt("Enter Latitude");
var outOfBoundsCheck = parseInt(LatitudeInputted);
while(outOfBoundsCheck > 80 || outOfBoundsCheck <- 80)
{
    alert("Latitude out of bounds");
    LatitudeInputted = window.prompt("Enter another latitude");
    outOfBoundsCheck = parseInt(LatitudeInputted);
}
var LongitudeInputted = window.prompt("Enter the longitude")
outOfBoundsCheck = parseInt(LongitudeInputted);
while(outOfBoundsCheck > 80 || outOfBoundsCheck <- 80)
{
    alert("Longitude out of bounds")
    LongitudeInputted = window.prompt("Enter another longitude")
    outOfBoundsCheck = parseInt(LongitudeInputted);
}

var i = 0;
//Marker colours
var colour = ["red", "green", "blue", "yellow","white","purple"];
var map;
//Button 3 count
var buttonThreeCount = 0;
var markerPositionAssign = "";
var markerAntiPositionAssign = "";
//Button 4 count
var buttonFourCount = 1;
var buttonFourCoordinates;
//Inputted Coordinates
var Coordinate = {
    lat:LatitudeInputted,
    lng:LongitudeInputted
};

function initialize(){
    var mapOptions=
    {
        center: new google.maps.LatLng(Coordinate.lat, Coordinate.lng),
        zoom: 4,
        mapTypeId: google.maps.MapTypeId.HYBRID
    };
        map = new google.maps.Map(document.getElementById('map'), mapOptions);
    
        //Button event listener
        document.getElementById('ChangeLocation').addEventListener('click', function() {
            changeLocation();  
        });
        document.getElementById('RandomPosition').addEventListener('click', function() {
            randomPosition();  
        });
        document.getElementById('GetAntipode').addEventListener('click', function() {
            getAntipode();  
        });
        document.getElementById('CreateSquare').addEventListener('click', function() {
            createSquare();  
        });
        document.getElementById('AddContourPoints').addEventListener('click', function() {
            addContourPoints();  
        });
        
    }

function changeLocation(){
    //Button 1 functionality
    var randomColour = colour[Math.floor(Math.random()*colour.length)];
    LatitudeInputted = window.prompt("Enter Latitude");
    var outOfBoundsCheck = parseInt(LatitudeInputted);
    while(outOfBoundsCheck > 80 || outOfBoundsCheck <- 80)
    {
        alert("Latitude out of bounds");
        LatitudeInputted = window.prompt("Enter another latitude");
        outOfBoundsCheck = parseInt(LatitudeInputted);
    }
    LongitudeInputted = window.prompt("Enter the longitude")
    outOfBoundsCheck = parseInt(LongitudeInputted);
    while(outOfBoundsCheck > 80 || outOfBoundsCheck <- 80)
    {
        alert("Longitude out of bounds")
        LongitudeInputted = window.prompt("Enter another longitude")
        outOfBoundsCheck = parseInt(LongitudeInputted);
    }
    var Coordinate = {
        lat:LatitudeInputted,
        lng:LongitudeInputted 
    };
    setLatLng = new google.maps.LatLng(Coordinate.lat,Coordinate.lng)
    var marker = new google.maps.Marker({
    position: new google.maps.LatLng(Coordinate.lat,Coordinate.lng),
    map:map,
    icon: "https://raw.githubusercontent.com/Concept211/Google-Maps-Markers/master/images/marker_"+randomColour+(i+1)+".png"
    });
    i++;
}

function randomPosition(){
    //Button 2 functionality
    var randomColour = colour[Math.floor(Math.random()*colour.length)];
    var circleLatLng = new google.maps.LatLng(Coordinate.lat,Coordinate.lng);
    circle = new google.maps.Circle({
        center: circleLatLng,
        radius: 300000,
    });
    //Getting the bounds for circle
    var surround = circle.getBounds();
    map.fitBounds(surround);
    var sw = surround.getSouthWest();
    var ne = surround.getNorthEast();
    var radLat = Math.random() * (ne.lat() - sw.lat()) + sw.lat();
    var radLng = Math.random() * (ne.lng() - sw.lng()) + sw.lng();
    var marker = new google.maps.Marker({
        position: new google.maps.LatLng(radLat, radLng),
        map:map,
        icon: "https://raw.githubusercontent.com/Concept211/Google-Maps-Markers/master/images/marker_"+randomColour+".png",   
        });
    map.panTo(new google.maps.LatLng(Coordinate.lat, Coordinate.lng));
    LatitudeInputted = radLat;
    LongitudeInputted = radLng;
}

function getAntipode(){
    //Button 3 functionality
    buttonThreeCount++;
    //Validates coordinates
    if(buttonThreeCount == 1)
    {
        var antiLatitude = window.prompt("Enter the latitude")
        var outOfBoundsCheck = parseInt(antiLatitude);
        while(outOfBoundsCheck > 80 || outOfBoundsCheck <- 80)
        {
            alert("Latitude out of bounds");
            antiLatitude = window.prompt("Enter another latitude");
            outOfBoundsCheck = parseInt(antiLatitude);
        }
        var antiLongitude = window.prompt("Enter the longitude")
        outOfBoundsCheck = parseInt(antiLongitude);
        while(outOfBoundsCheck > 80 || outOfBoundsCheck <- 80)
        {
            alert("Longitude out of bounds")
            antiLongitude = window.prompt("Enter another longitude")
            outOfBoundsCheck = parseInt(antiLongitude);
        }
        var Coordinate = {
            lat:antiLatitude,
            lng:antiLongitude 
        };
        console.log(Coordinate.lat, Coordinate.lng);
        setLatLng = new google.maps.LatLng(Coordinate.lat, Coordinate.lng);
        var marker = new google.maps.Marker({
            position: new google.maps.LatLng(Coordinate.lat, Coordinate.lng),
            map:map,
            icon: "https://raw.githubusercontent.com/Concept211/Google-Maps-Markers/master/images/marker_red.png",
            title: Coordinate.lat + "," + Coordinate.lng
        });
        map.panTo(new google.maps.LatLng(Coordinate.lat,Coordinate.lng));
        markerPositionAssign = marker.getPosition();

        marker.addListener('click', function(){
            map.setZoom(8);
        // Get latitude and longitude for antipode
            var antiCoordinate = {
                lat: getAntipodeLatitude(Coordinate.lat),
                lng: getAntipodeLongitude(Coordinate.lng)
            };
            console.log(antiCoordinate.lat, antiCoordinate.lng);
        var markerAnti = new google.maps.Marker({
            position: new google.maps.LatLng(antiCoordinate.lat, antiCoordinate.lng),
            map:map,
            icon: "http://maps.google.com/mapfiles/markerA.png",
            title:"Antipode for " +Coordinate.lat + "," + Coordinate.lng

        });
        map.panTo(new google.maps.LatLng(antiCoordinate.lat,antiCoordinate.lng));
        markerAntiPositionAssign = markerAnti.getPosition();
        });  
}
else
{
    if(buttonThreeCount % 2 == 0)
    {
        map.panTo(markerPositionAssign);
    }
    else
    {
        map.panTo(markerAntiPositionAssign);
    }

}
}
//Calculating Antipode
function getAntipodeLatitude(lat) {
    return lat * - 1;
  }
function getAntipodeLongitude(lng) {
    return lng > 0 ? lng - 180 : parseInt(lng) + 180;
  }
//Button 4
function createSquare(){
    //Error checking button 4
    if (buttonFourCount == 1)
    {
        var LatitudeInputtedTwo = window.prompt("Enter Latitude");
        var outOfBoundsCheck = parseInt(LatitudeInputtedTwo);
        while(outOfBoundsCheck > 80 || outOfBoundsCheck <- 80)
        {
            alert("Latitude out of bounds");
            LatitudeInputtedTwo = window.prompt("Enter another latitude");
            outOfBoundsCheck = parseInt(LatitudeInLatitudeInputtedTwoputted2);
        }
        var LongitudeInputtedTwo = window.prompt("Enter the longitude")
        outOfBoundsCheck = parseInt(LongitudeInputtedTwo);
        while(outOfBoundsCheck > 80 || outOfBoundsCheck <- 80)
        {
            alert("Longitude out of bounds")
            LongitudeInputtedTwo = window.prompt("Enter another longitude")
            outOfBoundsCheck = parseInt(LongitudeInputtedTwo);
        }
        //When button clicked once
        var Coordinate = {
            lat:LatitudeInputtedTwo,
            lng:LongitudeInputtedTwo 
        };
        setLatLng = new google.maps.LatLng(Coordinate.lat, Coordinate.lng);
        map.setZoom(4);
        var marker = new google.maps.Marker({
            position: new google.maps.LatLng(Coordinate.lat, Coordinate.lng),
            map:map,
            title: "Button clicked once"
        });
        map.panTo(new google.maps.LatLng(Coordinate.lat, Coordinate.lng));
        buttonFourCount++;
        buttonFourCoordinates ={
            lat:Coordinate.lat,
            lng:Coordinate.lng
        }  
    }
    //When button clicked twice
    else if(buttonFourCount == 2)
    {
        circle = new google.maps.Circle({
            center: new google.maps.LatLng(buttonFourCoordinates.lat,buttonFourCoordinates.lng),
            radius: 300000,
            
        });
        //Get circle bounds for marker
        var circleBounds = circle.getBounds();
        var rectangle = new google.maps.Rectangle({
            bounds: circleBounds,
            map: map
        });
        //Creating markers within rectangle region at random
        var x;
        for (x=0; x<=25; x++)
        {
            var southWest = circleBounds.getSouthWest();
            var northEast = circleBounds.getNorthEast();
            var ptLat = Math.random() * (northEast.lat() - southWest.lat()) + southWest.lat();
            var ptLng = Math.random() * (northEast.lng() - southWest.lng()) + southWest.lng();

            var regionMarker = new google.maps.Marker({
                position: new google.maps.LatLng(ptLat, ptLng),
                map:map,
                icon: "http://maps.google.com/mapfiles/ms/icons/yellow-dot.png"
            });
        }
        //Creating markers for 4 corners
        var storeAllBoundsArray = [];
        var infoWindow = new google.maps.InfoWindow;
        var rectangleBounds = rectangle.getBounds();
        var northEastBounds = rectangleBounds.getNorthEast();
        var southWestBounds = rectangleBounds.getSouthWest();
        var northWestBounds = new google.maps.LatLng(northEastBounds.lat(), southWestBounds.lng());
        var southEastBounds = new google.maps.LatLng(southWestBounds.lat(), northEastBounds.lng());
        storeAllBoundsArray.push(northEastBounds);
        storeAllBoundsArray.push(southWestBounds);
        storeAllBoundsArray.push(northWestBounds);
        storeAllBoundsArray.push(southEastBounds);
        for( var i = 0; i < storeAllBoundsArray.length; i++)
        {
            var cornerMarker = new google.maps.Marker({
                position: storeAllBoundsArray[i],
                map:map,
                icon: "http://maps.google.com/mapfiles/ms/icons/green-dot.png"
            });
            cornerMarker.addListener('click', function() {   
                var infoDiv = document.createElement("div");
                infoDiv.style.width = "200px";
                infoDiv.style.height= "200px";
                document.getElementById("map").appendChild(infoDiv);
                var overview = {
                    zoom: 8,
                    center: this.getPosition(),
                    mapTypeId: map.getMapTypeId(),
                    disableDefaultUI: true
                }; 
                var mapDetail = new google.maps.Map(infoDiv, overview);
                var infoMarker = new google.maps.Marker({
                    position: this.getPosition(),
                    map: mapDetail,
                    clickable: false
                });
                infoWindow.setContent(infoDiv);
                infoWindow.open(map, this);
                this.addListener('click', function() {
                    infoWindow.close(map, this);
                });
            });
        }         
    } 
} 

//Button 5
var markersToRemove = [];
var createNewShape;
var buttonFiveCount = 0;
function addContourPoints()   
{
    buttonFiveCount++;
    //Functionality only works when button is pressed once
    if(buttonFiveCount==1)
    {
        var drawingManager = new google.maps.drawing.DrawingManager({
            drawingControl: true,  
            drawingMode: google.maps.drawing.OverlayType.POLYGON,
            drawingControlOptions: {
                position: google.maps.ControlPosition.TOP_CENTER,
                drawingModes: ['polygon']
                },
   
            polygonOptions: {
                fillOpacity: 0.5,
                strokeColor: "#FF0000",
                editable: false,
                fillColor: "#00FFFF"
            }
        });
        drawingManager.setMap(map);
          
        google.maps.event.addListener(drawingManager, 'overlaycomplete', function(action){
            createNewShape = action.overlay;
            createNewShape.type = action.type;
            createNewShape.setMap(map);

            //Change colour of region when mouse hovers
            google.maps.event.addListener(createNewShape, 'mouseover', function()
            {
                createNewShape.setOptions({
                    fillOpacity: 0.5,
                    strokeColor:'#FF0000',
                    editable: false,
                    fillColor:'#0000FF'
                });
                createNewShape.setMap(map);
            //Places markers when mouse hovers over region
                google.maps.event.addListener(createNewShape,"mouseover",function(action)
                {
                    var markerAction;
                    markerAction = new google.maps.Marker({
                        position: action.latLng,
                        icon: 'http://maps.google.com/mapfiles/ms/icons/yellow-dot.png',
                        map: map
                    });
                    markersToRemove.push(markerAction);
                });

            });

            //Reverts back to original colour when mouse is out of region
            google.maps.event.addListener(createNewShape,"mouseout",function()
            {
                createNewShape.setOptions({
                    fillOpacity: 0.5,
                    strokeColor: "#FF0000",
                    editable: false,
                    fillColor: "#00FFFF"
                });
                createNewShape.setMap(map);
        }); 
        
    });
    
    }
    else 
    {
        for(var i=0; i<= markersToRemove.length-1; i++)
        {
            markersToRemove[i].setMap(null);
        }
        createNewShape.setMap(null);
        buttonFiveCount = 1;
    }
}
    
google.maps.event.addDomListener(window, 'load', initialize);